package com.example.autotools;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.minecraft.class_1269;
import com.example.autotools.handler.*;

public class AutoToolsMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.field_9236) return class_1269.field_5811;
            AutoToolHandler.onStartBreak(pos);
            return class_1269.field_5811;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            AutoToolHandler.tick(client.field_1724);
            BridgeHandler.tick(client.field_1724);
            ReplenishHandler.tick(client.field_1724);
            WoolSafetyHandler.tick(client.field_1724);
            WaterDropHandler.tick(client.field_1724);
            PickupNotifier.tick(client.field_1724);
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            ResourceHud.render(drawContext);
            PickupNotifier.render(drawContext);
        });
    }
}
