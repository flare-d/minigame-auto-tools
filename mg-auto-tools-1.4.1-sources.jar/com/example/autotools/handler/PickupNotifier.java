package com.example.autotools.handler;

import java.util.*;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_746;

public class PickupNotifier {
    private static final class_310 MC = class_310.method_1551();
    private static final List<Note> notes = new ArrayList<>();
    private static final Map<class_1792, Integer> prev = new HashMap<>();
    private static int tick = 0;

    public static void tick(class_746 player) {
        if (++tick % 5 != 0) return;

        class_1661 inv = player.method_31548();
        Map<class_1792, Integer> cur = new HashMap<>();
        for (int i = 0; i < class_1661.field_30638; i++) {
            class_1799 s = inv.method_5438(i);
            if (!s.method_7960()) cur.merge(s.method_7909(), s.method_7947(), Integer::sum);
        }

        for (Map.Entry<class_1792, Integer> e : cur.entrySet()) {
            int diff = e.getValue() - prev.getOrDefault(e.getKey(), 0);
            if (diff > 0) add(e.getKey(), diff);
        }

        prev.clear();
        prev.putAll(cur);
        notes.removeIf(n -> System.currentTimeMillis() - n.time > 3000);
    }

    private static void add(class_1792 item, int count) {
        for (Note n : notes) {
            if (n.item == item) {
                n.count += count;
                n.time = System.currentTimeMillis();
                return;
            }
        }
        notes.add(new Note(item, count));
    }

    public static void render(class_332 ctx) {
        if (notes.isEmpty()) return;
        class_327 tr = MC.field_1772;
        int y = 20;
        int h = 16;

        for (int i = 0; i < notes.size(); i++) {
            Note n = notes.get(i);
            class_1799 stack = new class_1799(n.item);
            String label = stack.method_7964().getString() + " +" + n.count;
            int tw = tr.method_1727(label);
            int x = 4;
            int py = y + i * h;

            ctx.method_51427(stack, x, py);
            ctx.method_27535(tr, class_2561.method_43470(label), x + 18, py + 4, 0xFFFFFF);
        }
    }

    private static class Note {
        class_1792 item;
        int count;
        long time;
        Note(class_1792 item, int count) { this.item = item; this.count = count; this.time = System.currentTimeMillis(); }
    }
}
