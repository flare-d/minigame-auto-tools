package com.example.autotools.handler;

import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class WaterDropHandler {
    private static final class_310 MC = class_310.method_1551();
    private static long lastWater = 0;
    private static final long COOLDOWN = 1000;

    public static void tick(class_746 player) {
        if (MC.field_1761 == null) return;
        if (player.field_7512 != player.field_7498) return;
        if (player.method_24828()) return;
        if (player.field_6017 < 3.0f) return;
        if (System.currentTimeMillis() - lastWater < COOLDOWN) return;
        if (BridgeHandler.placedThisTick) return;

        int waterSlot = findWater(player);
        if (waterSlot == -1) return;

        class_2338 ground = findGround(player);
        if (ground == null) return;

        double dist = player.method_23318() - (ground.method_10264() + 1);
        if (dist < 1.5 || dist > 4.0) return;

        int oldSlot = player.method_31548().field_7545;
        moveToHand(player, waterSlot);

        class_2338 place = player.method_24515().method_10074();
        if (!player.method_37908().method_8320(place).method_26215()) {
            place = ground.method_10084();
        }
        if (!player.method_37908().method_8320(place).method_26215()) {
            restoreSlot(player, waterSlot, oldSlot);
            return;
        }

        class_2338 support = place.method_10074();
        if (player.method_37908().method_8320(support).method_26215()) {
            support = ground;
        }

        class_243 hitVec = class_243.method_24953(support).method_1031(0, 0.9, 0);
        class_3965 bhr = new class_3965(hitVec, class_2350.field_11036, support, false);

        MC.field_1761.method_2896(player, class_1268.field_5808, bhr);
        lastWater = System.currentTimeMillis();

        restoreSlot(player, waterSlot, oldSlot);
    }

    private static int findWater(class_746 player) {
        class_1661 inv = player.method_31548();
        for (int i = 0; i < class_1661.field_30638; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8705)) return i;
        }
        return -1;
    }

    private static class_2338 findGround(class_746 player) {
        class_2338 pos = player.method_24515();
        for (int i = 1; i < 30; i++) {
            class_2338 d = pos.method_10087(i);
            if (!player.method_37908().method_8320(d).method_26215()) return d;
        }
        return null;
    }

    private static void moveToHand(class_746 player, int slot) {
        class_1661 inv = player.method_31548();
        if (slot < class_1661.method_7368()) {
            inv.field_7545 = slot;
            return;
        }
        int syncId = player.field_7498.field_7763;
        int src = toScreen(slot);
        int dst = toScreen(inv.field_7545);
        MC.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, player);
        MC.field_1761.method_2906(syncId, dst, 0, class_1713.field_7790, player);
    }

    private static void restoreSlot(class_746 player, int waterSlot, int oldSlot) {
        class_1661 inv = player.method_31548();
        if (waterSlot < class_1661.method_7368()) {
            inv.field_7545 = oldSlot;
            return;
        }
        int syncId = player.field_7498.field_7763;
        int src = toScreen(waterSlot);
        int dst = toScreen(oldSlot);
        MC.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, player);
        MC.field_1761.method_2906(syncId, dst, 0, class_1713.field_7790, player);
    }

    private static int toScreen(int invSlot) {
        return (invSlot >= 0 && invSlot < 9) ? 36 + invSlot : invSlot;
    }
}
