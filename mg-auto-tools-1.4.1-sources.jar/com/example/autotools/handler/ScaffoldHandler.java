package com.example.autotools.handler;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class ScaffoldHandler {
    private static final class_310 MC = class_310.method_1551();
    private static long lastPlace = 0;
    private static final long COOLDOWN = 50;

    public static boolean isScaffolding(class_746 player) {
        class_1799 hand = player.method_6047();
        if (!hand.method_31573(class_3489.field_15544)) return false;
        class_2338 below = player.method_24515().method_10074();
        return player.method_37908().method_8320(below).method_26215();
    }

    public static void tick(class_746 player) {
        if (MC.field_1761 == null) return;
        if (System.currentTimeMillis() - lastPlace < COOLDOWN) return;

        class_1799 hand = player.method_6047();
        if (!hand.method_31573(class_3489.field_15544)) return;
        if (player.method_18798().field_1351 > 0.1) return;

        class_2338 below = player.method_24515().method_10074();
        if (!player.method_37908().method_8320(below).method_26215()) return;

        class_2338 support = findSupport(player, below);
        if (support == null) return;

        class_2350 face = directionFrom(support, below);
        class_243 hitVec = class_243.method_24953(support).method_1019(class_243.method_24954(face.method_62675()).method_1021(0.5));
        class_3965 bhr = new class_3965(hitVec, face, support, false);

        var result = MC.field_1761.method_2896(player, class_1268.field_5808, bhr);
        if (result.method_23665()) {
            player.method_6104(class_1268.field_5808);
            lastPlace = System.currentTimeMillis();
        }
    }

    private static class_2338 findSupport(class_746 player, class_2338 target) {
        for (class_2350 d : class_2350.values()) {
            class_2338 n = target.method_10093(d);
            if (!player.method_37908().method_8320(n).method_26215()) return n;
        }
        return null;
    }

    private static class_2350 directionFrom(class_2338 from, class_2338 to) {
        int dx = to.method_10263() - from.method_10263();
        int dy = to.method_10264() - from.method_10264();
        int dz = to.method_10260() - from.method_10260();
        if (dx == 1) return class_2350.field_11034;
        if (dx == -1) return class_2350.field_11039;
        if (dy == 1) return class_2350.field_11036;
        if (dy == -1) return class_2350.field_11033;
        if (dz == 1) return class_2350.field_11035;
        if (dz == -1) return class_2350.field_11043;
        return class_2350.field_11036;
    }
}
