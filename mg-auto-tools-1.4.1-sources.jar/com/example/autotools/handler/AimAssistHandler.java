package com.example.autotools.handler;

import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public class AimAssistHandler {
    private static final class_310 MC = class_310.method_1551();
    private static final double REACH_SQ = 6.0 * 6.0;
    private static class_1309 target = null;

    public static void setTarget(class_1309 entity) {
        target = entity;
    }

    public static void tick(class_746 player) {
        if (target == null) return;

        if (target.method_31481() || !target.method_5805()
                || target.method_5858(player) > REACH_SQ
                || !player.method_6057(target)) {
            target = null;
            return;
        }

        aimSmooth(player, target);

        if (MC.field_1755 == null && MC.field_1761 != null
                && player.method_7261(0.0f) >= 1.0f) {
            MC.field_1761.method_2918(player, target);
            player.method_6104(class_1268.field_5808);
        }
    }

    private static void aimSmooth(class_746 player, class_1309 target) {
        class_243 eye = player.method_33571();
        class_243 c = target.method_5829().method_1005();
        double dx = c.field_1352 - eye.field_1352;
        double dy = c.field_1351 - eye.field_1351;
        double dz = c.field_1350 - eye.field_1350;
        double h = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float targetPitch = class_3532.method_15363((float) -Math.toDegrees(Math.atan2(dy, h)), -90f, 90f);

        float yaw = player.method_36454();
        float pitch = player.method_36455();

        float diffYaw = class_3532.method_15393(targetYaw - yaw);
        float diffPitch = targetPitch - pitch;

        player.method_36456(yaw + diffYaw * 0.5f);
        player.method_36457(pitch + diffPitch * 0.5f);
    }
}
