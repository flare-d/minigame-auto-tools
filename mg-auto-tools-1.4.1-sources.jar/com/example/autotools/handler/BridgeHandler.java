package com.example.autotools.handler;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class BridgeHandler {
    private static final class_310 MC = class_310.method_1551();
    private static long lastPlace = 0;
    private static final long COOLDOWN = 120;
    private static final long SAFETY_COOLDOWN = 60;
    private static long lastSafetyPlace = 0;
    public static boolean placedThisTick = false;
    private static final Map<class_2338, Long> recentPlacements = new HashMap<>();
    private static final long PLACEMENT_MEMORY_MS = 3000;

    public static void tick(class_746 player) {
        placedThisTick = false;
        if (MC.field_1761 == null) return;
        if (player.field_7512 != player.field_7498) return;

        cleanupRecent();

        // Safety: если под ногами нет твердого блока и мы падаем — срочно ставим
        if (!player.method_24828() && player.method_18798().field_1351 < -0.08) {
            class_2338 below = player.method_24515().method_10074();
            if (isUnsafe(player, below)) {
                if (System.currentTimeMillis() - lastSafetyPlace >= SAFETY_COOLDOWN) {
                    tryPlace(player, below, true);
                }
            }
        }

        if (System.currentTimeMillis() - lastPlace < COOLDOWN) return;

        class_1799 hand = player.method_6047();
        if (!(hand.method_7909() instanceof class_1747)) return;

        if (MC.field_1765 != null && MC.field_1765.method_17783() == class_239.class_240.field_1332) return;

        class_2338 target = findTarget(player);
        if (target == null) return;
        if (!player.method_37908().method_8320(target).method_26215()) return;
        if (player.method_5707(class_243.method_24953(target)) > 16.0) return;

        tryPlace(player, target, false);
    }

    private static boolean isUnsafe(class_746 player, class_2338 pos) {
        if (!player.method_37908().method_8320(pos).method_26215()) {
            return player.method_37908().method_8320(pos).method_26220(player.method_37908(), pos).method_1110();
        }
        return true;
    }

    private static void tryPlace(class_746 player, class_2338 target, boolean safety) {
        class_2338 support = findSupport(player, target);
        if (support == null) return;
        if (player.method_37908().method_8320(support).method_26215()) return;

        class_2350 face = directionFrom(support, target);
        class_243 hitVec = class_243.method_24953(support).method_1019(class_243.method_24954(face.method_62675()).method_1021(0.5));
        class_3965 bhr = new class_3965(hitVec, face, support, false);

        var result = MC.field_1761.method_2896(player, class_1268.field_5808, bhr);
        if (result.method_23665()) {
            player.method_6104(class_1268.field_5808);
            recentPlacements.put(target, System.currentTimeMillis());
            if (safety) {
                lastSafetyPlace = System.currentTimeMillis();
            } else {
                lastPlace = System.currentTimeMillis();
            }
            placedThisTick = true;
        }
    }

    private static void cleanupRecent() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<class_2338, Long>> it = recentPlacements.entrySet().iterator();
        while (it.hasNext()) {
            if (now - it.next().getValue() > PLACEMENT_MEMORY_MS) {
                it.remove();
            }
        }
    }

    private static class_2338 findTarget(class_746 player) {
        class_2338 feet = player.method_24515();

        if (player.method_37908().method_8320(feet.method_10074()).method_26215()) {
            return feet.method_10074();
        }

        class_2350 dir = yawToDirection(player.method_36454());
        class_2338 forward = feet.method_10093(dir);

        if (player.method_37908().method_8320(forward).method_26215()
                && player.method_37908().method_8320(forward.method_10074()).method_26215()) {
            return forward;
        }

        class_2338 forwardDown = forward.method_10074();
        if (player.method_37908().method_8320(forwardDown).method_26215()
                && player.method_37908().method_8320(forwardDown.method_10074()).method_26215()
                && player.method_18798().field_1351 < -0.1) {
            return forwardDown;
        }

        return null;
    }

    private static class_2338 findSupport(class_746 player, class_2338 target) {
        for (class_2350 d : class_2350.values()) {
            class_2338 n = target.method_10093(d);
            if (!player.method_37908().method_8320(n).method_26215()) return n;
        }
        return null;
    }

    private static class_2350 directionFrom(class_2338 from, class_2338 to) {
        int dx = to.method_10263() - from.method_10263();
        int dy = to.method_10264() - from.method_10264();
        int dz = to.method_10260() - from.method_10260();
        if (dx == 1) return class_2350.field_11034;
        if (dx == -1) return class_2350.field_11039;
        if (dy == 1) return class_2350.field_11036;
        if (dy == -1) return class_2350.field_11033;
        if (dz == 1) return class_2350.field_11035;
        if (dz == -1) return class_2350.field_11043;
        return class_2350.field_11036;
    }

    private static class_2350 yawToDirection(float yaw) {
        float n = class_3532.method_15393(yaw);
        if (n >= -45f && n < 45f) return class_2350.field_11035;
        if (n >= 45f && n < 135f) return class_2350.field_11039;
        if (n >= 135f || n < -135f) return class_2350.field_11043;
        return class_2350.field_11034;
    }
}
