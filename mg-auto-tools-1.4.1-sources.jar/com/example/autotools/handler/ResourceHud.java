package com.example.autotools.handler;

import java.lang.reflect.Field;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ResourceHud {
    private static final class_310 MC = class_310.method_1551();

    public static void render(class_332 ctx) {
        if (MC.field_1724 == null) return;

        int iron = count(class_1802.field_8620);
        int gold = count(class_1802.field_8695);
        int diamond = count(class_1802.field_8477);
        int emerald = count(class_1802.field_8687);

        class_327 tr = MC.field_1772;
        int gap = 44;
        int total = gap * 4;
        int sw = ctx.method_51421();
        int x = (sw - total) / 2;
        int y = getYOffset();

        draw(ctx, tr, x, y, class_1802.field_8620, iron, 0xFFFFFF);
        draw(ctx, tr, x + gap, y, class_1802.field_8695, gold, 0xFFD700);
        draw(ctx, tr, x + gap * 2, y, class_1802.field_8477, diamond, 0x00FFFF);
        draw(ctx, tr, x + gap * 3, y, class_1802.field_8687, emerald, 0x50C878);
    }

    private static int getYOffset() {
        int y = 4;
        if (MC.field_1705 == null || MC.field_1705.method_1740() == null) return y;

        int bars = getBossBarCount();
        if (bars > 0) y += bars * 14 + 2;
        return y;
    }

    @SuppressWarnings("unchecked")
    private static int getBossBarCount() {
        try {
            Field field = net.minecraft.class_337.class.getDeclaredField("bossBars");
            field.setAccessible(true);
            Map<?, ?> map = (Map<?, ?>) field.get(MC.field_1705.method_1740());
            return map != null ? map.size() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private static void draw(class_332 ctx, class_327 tr, int x, int y, net.minecraft.class_1792 item, int count, int color) {
        class_1799 s = new class_1799(item);
        ctx.method_51427(s, x, y);
        ctx.method_27535(tr, class_2561.method_43470(String.valueOf(count)), x + 17, y + 4, color);
    }

    private static int count(net.minecraft.class_1792 item) {
        if (MC.field_1724 == null) return 0;
        class_1661 inv = MC.field_1724.method_31548();
        int sum = 0;
        for (int i = 0; i < class_1661.field_30638; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_31574(item)) sum += s.method_7947();
        }
        return sum;
    }
}
