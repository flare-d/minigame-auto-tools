package com.example.autotools.handler;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class WoolSafetyHandler {
    private static final class_310 MC = class_310.method_1551();
    private static long lastWool = 0;
    private static final long COOLDOWN = 100;

    public static void tick(class_746 player) {
        if (player.method_24828()) return;
        if (player.method_18798().field_1351 >= -0.3) return;

        class_1799 hand = player.method_6047();
        if (!hand.method_31573(class_3489.field_15544)) return;
        if (System.currentTimeMillis() - lastWool < COOLDOWN) return;

        class_2338 below = player.method_24515().method_10074();
        if (!player.method_37908().method_8320(below).method_26215()) return;

        boolean supported = false;
        for (class_2350 d : class_2350.values()) {
            if (!player.method_37908().method_8320(below.method_10093(d)).method_26215()) {
                supported = true;
                break;
            }
        }
        if (!supported) return;

        class_243 hitVec = class_243.method_24953(below).method_1031(0, 0.9, 0);
        class_3965 bhr = new class_3965(hitVec, class_2350.field_11036, below, false);

        if (MC.field_1761 != null) {
            var res = MC.field_1761.method_2896(player, class_1268.field_5808, bhr);
            if (res.method_23665()) {
                player.method_6104(class_1268.field_5808);
                lastWool = System.currentTimeMillis();
            }
        }
    }
}
