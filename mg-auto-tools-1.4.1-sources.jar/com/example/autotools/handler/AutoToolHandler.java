package com.example.autotools.handler;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_746;

public class AutoToolHandler {
    private static final class_310 MC = class_310.method_1551();
    private static int originalSlot = -1;
    private static boolean active = false;
    private static class_2338 targetPos = null;

    public static void onStartBreak(class_2338 pos) {
        class_746 player = MC.field_1724;
        if (player == null) return;
        if (player.field_7512 != player.field_7498) return;
        originalSlot = player.method_31548().field_7545;
        targetPos = pos;
        active = true;
        selectBestTool(player, player.method_37908().method_8320(pos));
    }

    public static void tick(class_746 player) {
        if (!active) return;
        if (!MC.field_1690.field_1886.method_1434() || isBlockBroken(player)) {
            restore(player);
        }
    }

    private static boolean isBlockBroken(class_746 player) {
        return targetPos == null || player.method_37908().method_8320(targetPos).method_26215();
    }

    private static void restore(class_746 player) {
        if (player.field_7512 != player.field_7498) {
            active = false;
            targetPos = null;
            originalSlot = -1;
            return;
        }
        if (originalSlot >= 0 && originalSlot < class_1661.method_7368()) {
            player.method_31548().field_7545 = originalSlot;
        }
        active = false;
        targetPos = null;
        originalSlot = -1;
    }

    private static void selectBestTool(class_746 player, class_2680 state) {
        class_1661 inv = player.method_31548();
        int bestSlot = -1;
        float bestSpeed = -1f;
        class_1799 current = inv.method_7391();
        float currentSpeed = current.method_7924(state);

        for (int i = 0; i < class_1661.method_7368(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            if (stack.method_7909() instanceof class_1829) continue;

            float speed = stack.method_7924(state);

            if (state.method_26164(class_3481.field_15481) && stack.method_7909() instanceof class_1820
                    && !(current.method_7909() instanceof class_1820)) {
                bestSlot = i;
                break;
            }

            if (state.method_27852(class_2246.field_10343) && stack.method_7909() instanceof class_1820
                    && !(current.method_7909() instanceof class_1820)) {
                bestSlot = i;
                break;
            }

            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        if (bestSlot != -1 && bestSlot != inv.field_7545) {
            if (currentSpeed <= 1f || bestSpeed > currentSpeed) {
                inv.field_7545 = bestSlot;
            }
        }
    }
}
