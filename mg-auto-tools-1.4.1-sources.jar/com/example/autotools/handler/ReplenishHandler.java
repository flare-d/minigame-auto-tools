package com.example.autotools.handler;

import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class ReplenishHandler {
    private static final class_310 MC = class_310.method_1551();
    private static int lastSlot = -1;
    private static class_1792 lastItem = null;
    private static long lastClick = 0;
    private static final long COOLDOWN = 100;

    public static void tick(class_746 player) {
        if (MC.field_1761 == null) return;
        if (player.field_7512 != player.field_7498) return;

        int slot = player.method_31548().field_7545;
        class_1799 current = player.method_31548().method_5438(slot);

        if (slot != lastSlot) {
            lastSlot = slot;
            lastItem = current.method_7960() ? null : current.method_7909();
            return;
        }

        if (current.method_7960() && lastItem != null) {
            if (System.currentTimeMillis() - lastClick < COOLDOWN) return;

            int found = findSlot(player, lastItem, slot);
            if (found != -1) {
                int syncId = player.field_7498.field_7763;
                int src = toScreen(found);
                int dst = toScreen(slot);
                MC.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, player);
                MC.field_1761.method_2906(syncId, dst, 0, class_1713.field_7790, player);
                lastClick = System.currentTimeMillis();
            }
            lastItem = null;
        } else if (!current.method_7960()) {
            lastItem = current.method_7909();
        }
    }

    private static int findSlot(class_746 player, class_1792 item, int exclude) {
        class_1661 inv = player.method_31548();
        for (int i = 0; i < class_1661.field_30638; i++) {
            if (i == exclude) continue;
            if (inv.method_5438(i).method_31574(item)) return i;
        }
        return -1;
    }

    private static int toScreen(int invSlot) {
        return (invSlot >= 0 && invSlot < 9) ? 36 + invSlot : invSlot;
    }
}
